# dlgmod

CLI version of DialogModule for macOS
